import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class Logout extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throwsIOException,ServletException
	{
		HttpSession session=req.getSession();
		session.invalidate();
		res.sendRedirect("login.html");
	}

}