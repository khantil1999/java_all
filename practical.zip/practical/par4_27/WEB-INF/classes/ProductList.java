import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class ProductList extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws     IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		HttpSession session=req.getSession();

		String[] item=(String[])session.getAttribute("item_array");
		String user_name=(String)session.getAttribute("uname");
		int count=0;
		int total=0;
		out.print("<html><body>");
		out.print("<center>");
		out.print("<h4>CART</h4>");
		out.print("<table border='1'>");
		out.print("<tr>");
		out.print("<th> PRODUCT NAME</th>");
		out.print("<th> PRODUCT PRICE</th>");
		out.print("<th> PRODUCT QUENTITY</th>");
		out.print("</tr>");

		while(count<=item.length)
		{
			if(item[count]==null)
			{
				count=count+3;

			}
			else
			{
				int temp=count;
				total +=Integer.parseInt(item[temp+1])*Integer.parseInt(item[temp+2]);
				out.print("<tr>");
				out.print("<td>"+ item[temp]+"</td>");
				out.print("<td>"+Integer.parseInt(item[temp+1])*Integer.parseInt(item[temp+2])+"</td>");
				out.print("<td>"+ item[temp+2]+"</td>");
				out.print("</tr>");


			}
			count=count+3;
		}
		out.print("<tr>");
		out.print("<td colspan=3>TOTAL="+total+"</td>");
		out.print("</tr>");
		out.print("</table>");
		out.print("<br>");
		out.print("<button>");
		out.print("<a href='message.html'>PAY NOW </a>");
		out.print("</button><br><br>");

		out.print("<form action='logout' method='post'>");
		out.print("<input type='submit' name='sub' value='logout'>");
		out.print("</form>");
		out.print("</center>");

		out.print("</html></body>");



	}
}
