import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Product extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException
	{

		res.setContentType("text/html");
		PrintWriter out=res.getWriter();

		HttpSession session=req.getSession();
           String user_name=(String)session.getAttribute("uname");

		String  mobile_price=req.getParameter("mobile_price");
		String  pan_price=req.getParameter("pan_price");
		String  mouse_price=req.getParameter("mouse_price");

		String qty_mobile=req.getParameter("qty_moblie");
		String qty_pan=req.getParameter("qty_pan");
		String qty_mouse=req.getParameter("qty_mouse");

		String mobile_item=req.getParameter("item1");
		String pan_item=req.getParameter("item2");
		String mouse_item=req.getParameter("item3");

	//		out.print("USER NAME OR PASSWORD IS WRONG");
	//		RequestDispatcher rd=req.getRequestDispatcher("login.html");
	//		rd.forward(req,res);


		String []Item=new String[10];

		if(mobile_item!=null)
		{

			Item[0]=mobile_item;
			Item[1]=mobile_price;
			Item[2]=qty_mobile;


		}
		if(pan_item!=null)
		{
			Item[3]=pan_item;
			Item[4]=pan_price;
			Item[5]=qty_pan;
		}
		if(mouse_item!=null)
		{
			Item[6]=mouse_item;
			Item[7]=mouse_price;
			Item[8]=qty_mouse;
		}
		out.print(user_name);
		session.setAttribute("item_array",Item);
		RequestDispatcher rd=req.getRequestDispatcher("/productlist");
		rd.forward(req,res);

	}


}