import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Login extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException
	{

		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		ServletConfig config=getServletConfig();
		String name = config.getInitParameter("username");
		String pass=config.getInitParameter("password");
		String name1 = config.getInitParameter("usr1");
		String pass1=config.getInitParameter("psw");

		String u_name=req.getParameter("u_name");
		String psw=req.getParameter("pass");
		if( (name.equals(u_name) && pass.equals(psw)) || (name1.equals(u_name) && pass1.equals(psw)) )
		{

			HttpSession session=req.getSession();
            session.setAttribute("uname","admin");
			//RequestDispatcher rd=req.getRequestDispatcher("product.html");
			//rd.include(req,res);
			res.sendRedirect("product.html");

		}
		else
		{
			out.print("USER NAME OR PASSWORD IS WRONG");
			RequestDispatcher rd=req.getRequestDispatcher("login.html");
			rd.forward(req,res);

		}
	}


}