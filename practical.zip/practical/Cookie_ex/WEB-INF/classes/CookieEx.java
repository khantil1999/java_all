import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class CookieEx extends HttpServlet
{

	public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		int count=1;
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String uname=req.getParameter("uname");
		Cookie ck=new Cookie(uname,count+1+"");
		res.addCookie(ck);
		Cookie cks[]=req.getCookies();

		for(Cookie c: cks)
		{
			if(c.getName().equals(uname))
			{
				count=Integer.parseInt(c.getValue());

			}
		}
		out.println("username "+uname+" is visted for "+count+" times");


	}
}