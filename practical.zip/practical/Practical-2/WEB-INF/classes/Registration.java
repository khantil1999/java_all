import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public  class Registration extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.print("<center>");
        out.print("Name: "+req.getParameter("name"));
        out.print("<br>Address: "+req.getParameter("add"));
        out.print("<br>DoB: "+req.getParameter("dob"));
        out.print("<br>Gender: "+req.getParameter("gen"));
        out.print("<br>Hobbies: ");
        String hob[]=req.getParameterValues("hob");
        for(int i=0;i<hob.length;i++)
        {
            out.print(hob[i]+", ");
        }
        out.print("</center>");

    }
}
