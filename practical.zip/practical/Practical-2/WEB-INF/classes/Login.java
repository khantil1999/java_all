import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Login extends HttpServlet
{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();
        String uname=req.getParameter("uname");
        String pass=req.getParameter("upass");

        if(uname.equals("admin") && pass.equals("admin"))
        {
            Date d=new Date();
            out.print("You are login successfull.."+d.toString());
        }
        else
        {
            out.print("You are unauthorized user..");
        }
    }
}