import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;

public class ServletDemo implements Servlet
{
    ServletConfig config=null;
    String msg="";
    public void init(ServletConfig servletConfig) throws ServletException {
        config=getServletConfig();
         msg="Hello Servlet!!";
    }


    public ServletConfig getServletConfig() {
        return null;
    }


    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        out.print("<html><body>");
        out.print("<h2>"+msg+"</h2>");
        out.print("</body></html>");
        out.close();
    }


    public String getServletInfo() {
        return null;
    }


    public void destroy() {

    }
}
