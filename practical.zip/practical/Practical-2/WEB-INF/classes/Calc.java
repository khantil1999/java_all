import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Calc extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        Double a,b,ans;
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        a=Double.parseDouble(req.getParameter("no1"));
        b=Double.parseDouble(req.getParameter("no2"));
        if(req.getParameter("add").equals("+"))
        {
            out.print("Sum is: "+(a+b));
        }
        else if(req.getParameter("sub").equals("-"))
        {
            out.print("Subtraction is: "+(a-b));
        }
        else if(req.getParameter("mul").equals("*"))
        {
            out.print("Multiplication is: "+(a*b));
        }
        else if(req.getParameter("div").equals("/"))
        {
            out.print("Division is: "+(a/b));
        }
    }
}
