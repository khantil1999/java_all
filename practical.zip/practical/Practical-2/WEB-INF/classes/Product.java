import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Product extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.print("<html><body><center>");
        out.print("Name: "+req.getParameter("name"));
        out.print("<br>Email Address: "+req.getParameter("email"));
        out.print("<br>Mobile no: "+req.getParameter("mobile"));
        out.print("<br>DoB: "+req.getParameter("dob"));
        out.print("<br>Gender: "+req.getParameter("gender"));
        out.print("<br>Product name: "+req.getParameter("product"));
        out.print("<br>Product cost: "+req.getParameter("cost"));
        out.print("<br>Satisfaction: "+req.getParameter("sat"));
        out.print("<br>Comments: "+req.getParameter("cmts"));
        out.print("</center></body></html>");
    }
}
