import javax.servlet.*;
import java.io.*;
import java.util.*;
public class GenericServletDemo extends GenericServlet
{
    public void service(ServletRequest req,ServletResponse res)throws ServletException,IOException
    {
        Date d=new Date();
        Calendar cal=Calendar.getInstance();
        int day=cal.get(Calendar.DAY_OF_YEAR);
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();
        out.print("<html><body>");
        out.print("<h2> Welcome"+d.toString()+"</h2>");
        out.print("number of days in year : "+day);
        out.print("</body></html>");
    }
}