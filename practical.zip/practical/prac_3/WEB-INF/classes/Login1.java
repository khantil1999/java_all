import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class Login1 extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		ServletConfig ctx=getServletConfig();
		String uname=ctx.getInitParameter("unm");
		String pass=ctx.getInitParameter("pas");

		if(req.getParameter("name").equals(uname) && req.getParameter("psw").equals(pass))
		{
			RequestDispatcher rd=req.getRequestDispatcher("welcome.html");
			rd.forward(req,res);
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("login.html");
			rd.include(req,res);
		}

	}
}