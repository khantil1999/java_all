import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class Login extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		ServletContext ctx=getServletContext();
		String uname=ctx.getInitParameter("uname");
		String pass=ctx.getInitParameter("pass");

		if(req.getParameter("name").equals(uname) && req.getParameter("psw").equals(pass))
		{
			res.sendRedirect("welcome.html");
		}
		else
		{
			res.sendRedirect("login.html");
		}

	}
}