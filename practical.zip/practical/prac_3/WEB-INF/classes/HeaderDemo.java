import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class HeaderDemo extends HttpServlet
{
	int count=0;
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{

		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		count++;
		out.print("<html><body>");
		out.print("number of counts: "+count+"<br>");
		out.print("Request URI: "+req.getRequestURI()+"<br>");
		out.print("Request protocol: "+req.getProtocol()+"<br>");
		out.print("Path: "+req.getPathInfo()+"<br>");
		out.print("IP address: "+req.getRemoteAddr()+"<br>");
		out.print("</body></html>");
	}
}