import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class Welcome extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String uname=req.getParameter("uname");
		ServletConfig config=getServletConfig();
		String color=config.getInitParameter("color");
		out.print("<html><body bgcolor='"+color+"'>");
		out.print("<h1> Welcome "+uname+"</h1>");
		out.print("</body></html>");
	}
}