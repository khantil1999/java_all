import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.time.*;
public class AutoRefresh extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		LocalTime time=LocalTime.now();
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		res.setIntHeader("Refresh",1);
		out.print("<html><body>");
		out.print("<h1>"+time+"</h1>");
		out.print("</body></html>");
	}
}